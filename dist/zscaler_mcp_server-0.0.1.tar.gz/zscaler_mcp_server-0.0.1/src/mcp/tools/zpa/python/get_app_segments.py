from mcp.sdk.python.zscaler_client import get_zscaler_client

def get_app_segments(
    cloud: str,
    client_id: str,
    client_secret: str,
    customer_id: str,
    vanity_domain: str
) -> list[str]:
    client = get_zscaler_client(
        client_id=client_id,
        customer_id=customer_id,
        vanity_domain=vanity_domain,
        client_secret=client_secret,
        cloud=cloud,
    )

    segments = client.zpa.application_segment.list_segments()
    return [seg.name for seg in segments]

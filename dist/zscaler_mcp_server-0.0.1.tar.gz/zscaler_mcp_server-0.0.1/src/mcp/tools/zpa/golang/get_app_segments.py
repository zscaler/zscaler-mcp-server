from mcp.sdk.golang.zpa_cli_wrapper import list_segments_from_go_sdk

def get_app_segments(cloud: str, config_path: str) -> list[str]:
    return list_segments_from_go_sdk(cloud=cloud, config=config_path)

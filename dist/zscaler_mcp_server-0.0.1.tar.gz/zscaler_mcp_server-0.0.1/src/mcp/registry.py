from mcp.tools.zpa.python.get_app_segments import get_app_segments as get_app_segments_py
from mcp.tools.zpa.golang.get_app_segments import get_app_segments as get_app_segments_go

def register_all_tools(app):
    app.tool(name="get_app_segments_python")(get_app_segments_py)
    app.tool(name="get_app_segments_go")(get_app_segments_go)

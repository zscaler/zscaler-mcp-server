import asyncio
from mcp.server.fastmcp import FastMCP
from mcp.server.stdio import stdio_server
from mcp.server import InitializationOptions
from mcp.registry import register_all_tools


app = FastMCP("zscaler-mcp-server")
register_all_tools(app)

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="zscaler-mcp-server",
                server_version="0.1.0",
                capabilities=app.get_capabilities(),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())
